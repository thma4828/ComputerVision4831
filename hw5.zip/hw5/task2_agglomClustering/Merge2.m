function new = Merge2(c1, c2)


end